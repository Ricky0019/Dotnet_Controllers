using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Gridview.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace Gridview.Controllers
{
    public class GridController : Controller
    {
        employee employee = new employee();
        public IActionResult Index()
        {
            List<Info>emplist = new List<Info>();
            emplist = employee.GetAllEmployee().ToList();
            return View(emplist);
        }
        public IActionResult DropDownDemo()
        {
          Depratment dept = new Depratment();
            var deptList = dept.GetDepartments();
            ViewBag.dept = new SelectList(deptList, "DeptId","DeptName");
            return View();
        }
       
  
    }
}