using System.Collections.Generic;
using System.Data.SqlClient;
using System;

namespace Gridview.Models
{
    public class Depratment
    {
        string connectionstring;
        public Depratment()
        {
            connectionstring = "Data Source=01-011140; Initial Catalog=GridView; Integrated Security=false; User ID=sa; password=login@123;";
        }
          
        // To get all employee...
        public IEnumerable<departmentvm> GetDepartments()
        {
            List<departmentvm> deptList = new List<departmentvm>();

            using (SqlConnection con = new SqlConnection(connectionstring))
            {
                SqlCommand cmd = new SqlCommand("SELECT [Dept_Id],[Dept_Name]  FROM [GridView].[dbo].[Dept] ", con);
                cmd.CommandType = System.Data.CommandType.Text;
                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    departmentvm dept = new departmentvm();
                    
                    dept.DeptId = Convert.ToInt32(Convert.ToString(dr[0]));
                    dept.DeptName = Convert.ToString(dr[1]);
                    deptList.Add(dept);
                }
                con.Close();
            }
            return deptList;
        }  // getting all employees done...
    }
}