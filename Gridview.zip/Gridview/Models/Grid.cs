using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System;



namespace Gridview.Models
{
    public class employee
    {
        string connectionstring = "Data Source=01-011140; Initial Catalog=GridView; Integrated Security=false; User ID=sa; password=login@123;";
        // To get all employee...
        public IEnumerable<Info> GetAllEmployee()
        {
            List<Info> empList = new List<Info>();

            using (SqlConnection con = new SqlConnection(connectionstring))
            {
                SqlCommand cmd = new SqlCommand("SP_EmpDept", con);

                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    Info emp = new Info();
                    
                    emp.Emp_Name = dr[0].ToString();
                    emp.Dept_Count = Convert.ToInt32(dr[1].ToString());
                    empList.Add(emp);
                }
                con.Close();
            }
            return empList;
        }  // getting all employees done...

    }
}