namespace Gridview.Models
{
    public class Info
    {
       
        public string Emp_Name { get; set; }
       
        public int Dept_Count { get; set; }

    }
}