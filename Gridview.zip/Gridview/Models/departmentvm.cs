namespace Gridview.Models
{
    public class departmentvm
    {
        public int DeptId { get; set; }
        public string DeptName { get; set; }
    }
}